# Dado duas listas, printe todos os valores que aparecerem
# duplicados nas duas listas.

# Dado duas listas, printe uma mensagem dizendo se existe
# algum elemento em comum entre elas ou não.

