def minha_funcao():
    print('Rodando a minha função!')
    return 'RETORNO'


x = 30
