
# https://docs.streamlit.io/develop/api-reference
# Executar o STREAMLIT no terminal: streamlit run EDA_FRONT_v000.py

# diversos videos sobre MT5 python e streamlit
# https://www.mql5.com/en/forum/445467/page7
# https://www.youtube.com/watch?v=Ao9DpMLTosg
# https://github.com/azario0/metatrader5-streamlit/blob/main/main.py
# https://github.com/appznoix



import streamlit as st
import pandas as pd
import pandas_ta as ta
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
 
 # MODEL LIBS ##############################################################################
import datetime as dt
from datetime import datetime
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
# PRE-PROCESSING
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, StandardScaler, MaxAbsScaler, RobustScaler
# WARNING
import warnings
warnings.filterwarnings("ignore")
 
 # HEADER SETTINGS ##############################################################################

st.set_page_config(
    page_title="Maxtrade - Mercado Financeiro",
    page_icon="🤑",
    layout='wide'
)

st.title("📈 Maxtrade - Model ")
#st.header("")

#
#    """
#        # Maxtrade model
#        exibindo o primeiro texto com streamlit.
# 
#
#    """
#  
#)


 # DATASET ##############################################################################
base = pd.read_csv('WDO$_M5_202103101400_202410181825.csv', sep='\t')
base.drop(columns=['<SPREAD>'], inplace=True)
base.rename(columns={
            '<DATE>': 'Date', 
            '<TIME>': 'Time', 
            '<OPEN>': 'Open', 
            '<HIGH>': 'High', 
            '<LOW>' : 'Low', 
            '<CLOSE>': 'Close', 
            '<TICKVOL>':'Tick', 
            '<VOL>': 'Volume'}, inplace = True)
#base['Datetime'] = pd.to_datetime(base['Date']+' '+base['Time'])
base['Datetime'] = base['Date']+' '+base['Time']
base.set_index(base['Date']+' '+base['Time'], inplace=True)
base = base[-600:]
#st.write(df_base.tail())
#st.write(


# MODEL ##############################################################################
df = base.tail(10000)

df = df[df['Date']< df['Date'].max()]

# Função para criar a coluna 'Target' e 'Target_fut'
def add_target_columns(df):
    df['Target'] = (df['Close'] > df['Close'].shift(1)).astype(int)
    df['Target_fut'] = df['Target'].shift(-1)
    df['Target_fut'].fillna(0, inplace=True)  # Preenche NaN no último registro
    return df

df = add_target_columns(df)

# Selecionando as variáveis X e Y
X = df[['Open', 'High', 'Low', 'Close', 'Tick', 'Volume']]
Y = df['Target_fut']

# Definindo o tamanho do conjunto de treino (80% dos dados)
train_size = int(len(X) * 0.8)

# Dividindo os dados em treino e teste mantendo a ordem temporal
X_train, X_test = X[:train_size], X[train_size:]
Y_train, Y_test = Y[:train_size], Y[train_size:]

scaler = StandardScaler() # MinMaxScaler, StandardScaler, MaxAbsScaler, RobustScaler

X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)

# Criando e treinando o modelo de regressão logística
#model = LogisticRegression(random_state=42, class_weight='balanced')
model = RandomForestClassifier(random_state=42, class_weight='balanced',max_depth=5) # 60% de acertos no Estudos

model.fit(X_train, Y_train)

# Fazendo previsões
predictions = model.predict(X_test)
probability = model.predict_proba(X_test)

estudo = base.tail(1)
estudo = estudo[['Open', 'High', 'Low', 'Close', 'Tick', 'Volume']]
pred = []
proba = []

# Ajustar o scaler aos dados de entrada
scaler.fit(estudo)
for index, row in estudo.iterrows():
    row_reshaped = row.values.reshape(1,-1)
    
    # Normalizar os dados
    row_normalized = scaler.transform(row_reshaped)
    
    prediction = model.predict(row_normalized)
    probability = model.predict_proba(row_normalized)
    
    pred.append(prediction[0])
    proba.append(probability[0].max())

estudo['pred'] = pred
estudo['proba'] = proba

# DASH ##############################################################################

def highlight_selection(df, date_column, suggested_date=None):
    #converte a coluna de datas para datetime, se necessário
    df[date_column] = pd.to_datetime(df[date_column])
    
    #Verificar se a data sugerida foi fornecida
    if suggested_date:
        try:
            selected_date = pd.to_datetime(suggested_date, format='%Y.%m.%d')
        except:
            print("Formato de data invalido. Use o Formato 'YYYY.MM.DD'.")
            return None
    else:
        #identificar a ultima data (data_max) se a data sugerida não for fornecida
        selected_date = df[date_column].max()
         
    data_min = df[df[date_column] < selected_date][date_column].max()
    
    #filtar o DataFrame para incluir apenas as linhas entre data_min e data_max
    df_filtered = df[(df[date_column] >= data_min) & (df[date_column] <= selected_date)]
    df_filtered2 = df[df[date_column] == data_min]
    
    return df_filtered, df_filtered2.High.max(), df_filtered2.Low.min()


df_base, data_min_high, data_min_low = highlight_selection(base, 'Date') #, '2024.10.15' # insira a data sugerida para avaliação ou deixe em branco para capturar o max

# SUPORTE E RESISTÊNCIA ###########################################################################################
def is_resistance(df,i):
    resistence = (df['High'][i] > df['High'][i-1]
         and df['High'][i] > df['High'][i+1]
         and df['High'][i+1] > df['High'][i+2]
         and df['High'][i-1] > df['High'][i-2])
    return resistence

def is_support(df,i):
    support = (df['Low'][i] < df['Low'][i-1]
         and df['Low'][i] < df['Low'][i+1]
         and df['Low'][i+1] < df['Low'][i+2]
         and df['Low'][i-1] < df['Low'][i-2])
    return support


coordinates = []
for i in range(2, df_base.shape[0] - 2):
    if is_support(df_base, i):
        coordinates.append([
          (df_base.index[i], df_base['Low'][i]), # If support, plot a horizontal line from the low
          (max(df_base.index),df_base['Low'][i])
        ])
    elif is_resistance(df_base, i):
        coordinates.append([
          (df_base.index[i],df_base['High'][i]), # If resistance, plot a horizontal line from the high
          (max(df_base.index),df_base['High'][i])
        ])

#coordinates[:5]
avg_candle_size =  np.mean(df_base['High'] - df_base['Low'])

def is_far_from_level(price, levels, delta):
    is_far = True
    for level in levels:
        if (abs(level - price) < delta):
            is_far = False
            break
    return is_far

no_noise_levels = []
coordinates = []

# We skip the first and the last 2 data points once we need at least 5 candles
# to form the patter
for i in range(2, df_base.shape[0] - 2):

    if is_support(df_base, i):
        price = df_base['Low'][i]
        if is_far_from_level(price, no_noise_levels, avg_candle_size):
            no_noise_levels.append(price)
            coordinates.append([
                (df_base.index[i], price), (max(df_base.index), price)
            ])
            
    elif is_resistance(df_base,i):
        price = df_base['High'][i]
        if is_far_from_level(price, no_noise_levels, avg_candle_size):
            no_noise_levels.append(price)
            coordinates.append([
                (df_base.index[i], price), (max(df_base.index), price)
            ])

c_start = []
c_end = []
c_n_price = []
c_n_price_below = []


for i in range(len(coordinates)):
    c_start.append(coordinates[i][0][0])
    c_end.append(coordinates[i][1][0])
    new_price = coordinates[i][0][1]
    c_n_price.append(new_price)
    new_price_below = coordinates[i][1][1]
    c_n_price_below.append(new_price_below)
    
c_data = {'start' : c_start,
        'end' : c_end,
        'n_price': c_n_price,
        'n_price_below' : c_n_price_below}

df_cordinates = pd.DataFrame(c_data)

# CHANNEL FIMATHE #################################################################################################
# Verifique o preço de abertura do primeiro candle e gere um loop para adicionar ou subtrair o VALOR do channel_size
channel_size = 10.0
df_atual = df_base[df_base["Date"]==df_base['Date'].max()]
first_time_price =  df_atual['Datetime'].iloc[0]
last_time_price =  df_atual['Datetime'].max()
first_open_price = df_atual['Open'].iloc[0]
start = []
end = []
n_price = []
n_price_below = []


for i in range(8):
    start.append(first_time_price)
    end.append(last_time_price)
    new_price = first_open_price + (i * channel_size)
    n_price.append(new_price)
    new_price_below = first_open_price - (i * channel_size)
    n_price_below.append(new_price_below)
    
data = {'start' : start,
        'end' : end,
        'n_price': n_price,
        'n_price_below' : n_price_below}
df_channel = pd.DataFrame(data)

# VWAP ##############################################################################
df_base2 = df_base.copy()
df_base2.index = pd.to_datetime(df_base2.Datetime)
df_base2["VWAP"]=ta.vwap(df_base2.High, df_base2.Low, df_base2.Close, df_base2.Volume)
VWAPsignal = [0]*len(df_base2)
backcandles = 15

for row in range(backcandles, len(df_base2)):
    upt = 1
    dnt = 1
    for i in range(row-backcandles, row+1):
        if max(df_base2.Open[i], df_base2.Close[i])>=df_base2.VWAP[i]:
            dnt=0
        if min(df_base2.Open[i], df_base2.Close[i])<=df_base2.VWAP[i]:
            upt=0
    if upt==1 and dnt==1:
        VWAPsignal[row]=3
    elif upt==1:
        VWAPsignal[row]=2
    elif dnt==1:
        VWAPsignal[row]=1

df_base2['VWAPSignal'] = VWAPsignal
df_base['VWAP'] = df_base2['VWAP']


##------------------------------ Predict --------------------------------------------


col1, col2, col3, col4 = st.columns([2,2,1,1])

with col1:
        "\n"
        st.write(estudo.tail())

with col3:
        
        st.write("Previsão")
with col4:
        st.write("Probabilidade")


###-------------------------------------------------------------------------------------
y_proba = estudo['proba'][-1] #0.3 

with col3:
    #st.write("Previsão")
    if y_proba >= 0.7:
        st.info('Subir ⬆️')
    elif y_proba <= 0.3:
        st.error('Descer ⬇️')
    else:
        st.warning('Na mesma 😐')

with col4:
    #st.write("Probabilidade")
    #st.subheader(y_proba[0])
    if y_proba >= 0.7:
        #st.info(round(y_proba[0],4))
        st.info(y_proba)
    elif y_proba <= 0.3:
        #st.error(round(y_proba[0],4))
        st.error(y_proba)
    else:
        #st.warning(round(y_proba[0],4))
        st.warning(y_proba)

###-------------------------------------------------------------------------------------



 #GRAPHS ##############################################################################

#https://www.youtube.com/watch?v=dDgLKLXl9zw&list=PLgf5tk2HvlhONM16aLWjhdJPxRptglWdW&index=2
#https://github.com/thefullstackninja/Streamlit_tutorials
# https://www.youtube.com/watch?v=ovKgQdiQsHE


 #GRAPHS 2 ##############################################################################
price_bins = df_base.copy()
price_bins["Close"] = price_bins["Close"].round(4)
price_bins = price_bins.groupby("Close", as_index=False)["Volume"].sum()
price_bins["Percentage"] = price_bins["Volume"]*100/price_bins["Volume"].sum()

# Moving average over a window of 3 and 8
df_base['moving9'] = df_base['Close'].rolling(9).mean().round(2)
df_base['moving21'] = df_base['Close'].rolling(21).mean().round(2)

candles = make_subplots(rows=2,
                        cols=2,
                        shared_xaxes="columns",
                        shared_yaxes="rows",
                        column_width=[0.8, 0.2],
                        row_heights=[0.8, 0.2],
                        horizontal_spacing=0.05,
                        vertical_spacing=0,
                        specs=[[{"secondary_y": True}, {"secondary_y": True}], [{"colspan": 2}, None]])
    
    
candles.add_trace(go.Candlestick(x = df_base['Datetime'],
                                open = df_base['Open'],
                                high = df_base['High'],
                                low = df_base['Low'],
                                close = df_base['Close'],
                                name = 'WDO'),
                                row = 1, col =1)

candles.update_yaxes(
    showticklabels=True,
    showspikes=True,
    showgrid=False,
    col=1,
    row=1)
# add SMA 9
# adiciona as linhas no grafico de candles
candles.add_trace(go.Scatter(x=df_base['Datetime'],
                       y= df_base['moving9'],
                       mode = 'lines',
                       line_color = 'blue',
                       ), row = 1, col =1) 

# add SMA 21
candles.add_trace(go.Scatter(x=df_base['Datetime'],
                       y= df_base['moving21'],
                       mode = 'lines',
                       line_color = 'green',
                       ), row = 1, col =1) 

# add VWAP (15 periodos)
candles.add_trace(go.Scatter(x=df_base['Datetime'],
                       y= df_base['VWAP'],
                       mode = 'lines',
                       line_color = 'yellow',
                       ), row = 1, col =1) 

#adicionando uma linha fixa com a VWAP do tultimo candle do dia Anterior
candles.add_shape(type="line", x0= df_base.iloc[114][8], 
                            y0 = df_base.iloc[110][9],
                            x1 = df_base.iloc[-1][8],
                            y1 = df_base.iloc[110][9], 
                            fillcolor = 'red',
                            opacity=0.7)


#adicionando uma linha com a maxima e minima do dia Anterior
candles.add_shape(type="line", x0= df_base.iloc[110][8], 
                            y0 = data_min_high,
                            x1 = df_base.iloc[-1][8],
                            y1 = data_min_high, 
                            fillcolor = 'red',
                            opacity=0.7)
candles.add_shape(type="line", x0= df_base.iloc[110][8], 
                            y0 = data_min_low,
                            x1 = df_base.iloc[-1][8],
                            y1 = data_min_low, 
                            fillcolor = 'red',
                            opacity=0.7)




#################################
# Adicionar uma linha em um ponto específico do gráfico
#candles.add_shape(type="line", 
##                  x0='16:30:00', y0=5700,
#                  x1='18:25:00', y1=5700, 
#                  fillcolor='#FF4B4B',
#                  opacity=1)

#for row in df1.iterrows():
#    fig.add_shape(type="line", x0= row[1]['dates'], 
#                            y0 = row[1]['levels'],
#                            x1 = df.date.max(),
#                            y1 = row[1]['levels'], fillcolor = 'yellow')

for row in df_cordinates.iterrows():
    candles.add_shape(type="line", x0= row[1]['start'], 
                            y0 = row[1]['n_price'],
                            x1 = row[1]['end'],
                            y1 = row[1]['n_price'], 
                            fillcolor = 'red',
                            opacity=0.1)


for row in df_channel.iterrows():
    candles.add_shape(type="line", x0= row[1]['start'], 
                            y0 = row[1]['n_price'],
                            x1 = row[1]['end'],
                            y1 = row[1]['n_price'], 
                            fillcolor = 'yellow',
                            opacity=0.5)

for row in df_channel.iterrows():
    candles.add_shape(type="line", x0= row[1]['start'], 
                            y0 = row[1]['n_price_below'],
                            x1 = row[1]['end'],
                            y1 = row[1]['n_price_below'], 
                            fillcolor = 'yellow',
                            opacity=0.5)
#################################

# grafico de volume
candles.add_trace(go.Bar(
    x = df_base['Datetime'],
    y = df_base['Volume'],
    name = 'Volume',
    marker_color = 'white', opacity = 0.13), row =1, col = 1, secondary_y = True)

# grafico de barras lateral com as zonas com concentração de volume
candles.add_trace(
    go.Bar(
        y=price_bins["Close"],
        x=price_bins["Volume"],
        text=price_bins["Percentage"],
        name="Price Bins",
        orientation="h",
        marker_color="purple",
        texttemplate="%{text:.2f}% @ %{y}",
        hoverinfo="x+y"
    ),
    col=2,
    row=1,
)



candles.update_xaxes(
    showticklabels=True,
    showspikes=True,
    showgrid=True,
    col=2,
    row=1)

    
candles.update_layout(xaxis_rangeslider_visible = False, annotations=[dict(x='16:30:00', y=5680.0, xref='x', yref='y',
                        showarrow=False, xanchor='left', text='Canal de Referência')]) 

candles.update_layout(margin=dict(l=5, r=5, t=5, b=5), height=600, showlegend=False, template='plotly_dark') #,title="Meu Dash" 




st.plotly_chart(candles)




##-----