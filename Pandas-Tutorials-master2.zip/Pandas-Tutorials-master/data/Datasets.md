# Datasets

* [internshala_dataset_raw.csv](https://www.kaggle.com/dhairyatalsania/internshalaindia-raw-dataset?select=internshala_dataset_raw.csv)
* [Significant Earthquakes, 1965-2016](https://www.kaggle.com/usgs/earthquake-database)
* [Medium articles dataset](https://www.kaggle.com/dorianlazar/medium-articles-dataset)
* [Students Performance in Exams](https://www.kaggle.com/spscientist/students-performance-in-exams)
* [World_population](https://en.wikipedia.org/wiki/World_population)
