#!/usr/bin/env python
# coding: utf-8

# In[54]:


### Curso de Python para Finanças Quantitativas

#### Aula 6 - Cruzamento de Médias móveis
#### Autor: Leandro Guerra - Outspoken Market
#### Download em: https://www.outspokenmarket.com/pythonfinancasquantitativas.html


# In[55]:


import pandas as pd
import numpy as np
from datetime import datetime
import yfinance as yf
import matplotlib.pyplot as plt


# In[56]:


plt.style.use("fivethirtyeight")
# https://matplotlib.org/stable/gallery/style_sheets/style_sheets_reference.html


# In[57]:


# Carrega a base

df = yf.download("PETR4.SA", "2018-01-01", "2021-12-31")

df


# In[58]:


# Visualização

plt.figure(figsize=(12.5,4.5))
plt.plot(df["Adj Close"], label = "PETR4", linewidth = 2, color = "blue")
plt.title("PETR4 Fechamento")
plt.xlabel("2018 à 2021")
plt.ylabel("Cotação")
plt.legend(loc = "lower right")
plt.show()


# In[59]:


# Cria as médias móveis

p1 = 10
p2 = 25

ma1 = pd.DataFrame()
ma1["Media_curta"] = df["Adj Close"].rolling(window = p1).mean()

ma2 = pd.DataFrame()
ma2["Media_longa"] = df["Adj Close"].rolling(window = p2).mean()


# In[60]:


# Vizualiza todos os dados

plt.figure(figsize = (16, 10))
plt.plot(ma1["Media_curta"], label = "Média curta", linewidth = 1, color = "red")
plt.plot(ma2["Media_longa"], label = "Média longa", linewidth = 1, color = "black")
plt.plot(df["Adj Close"], label = "PETR4", linewidth = 2, color = "blue")
plt.title("Fechamento")
plt.xlabel("2018 à 2021")
plt.ylabel("Cotação e médias")
plt.legend(loc = "lower right")
plt.show()


# In[61]:


# Criando um dataframe separado para criar a regra

df_regra = pd.DataFrame()
df_regra["Ativo"] = df["Adj Close"]
df_regra["Media_curta"] = ma1["Media_curta"]
df_regra["Media_longa"] = ma2["Media_longa"]
df_regra


# In[62]:


# Cria a regra do sinal
def regra(base):
    preco_compra = []
    preco_venda = []
    aux = 1
    
    for i in range(len(base)):
        if base["Media_curta"][i] > base["Media_longa"][i]:
            if aux != 1:
                preco_compra.append(base["Ativo"][i])
                preco_venda.append(np.nan)
                aux = 1
            else:
                preco_compra.append(np.nan)
                preco_venda.append(np.nan)
        elif base["Media_curta"][i] < base["Media_longa"][i]:
            if aux != 0:
                preco_compra.append(np.nan)
                preco_venda.append(base["Ativo"][i])
                aux = 0
            else:
                preco_compra.append(np.nan)
                preco_venda.append(np.nan)
        else:
            preco_compra.append(np.nan)
            preco_venda.append(np.nan)
    
    return (preco_compra, preco_venda)


# In[63]:


# Armazena os valores
compra, venda = regra(df_regra)
sinal = pd.DataFrame()
sinal["Compra"] = compra
sinal["Venda"] = venda
df_regra["Compra"] = compra
df_regra["Venda"] = venda


# In[64]:


# Visualiza o cruzamento
plt.figure(figsize = (16, 10))
plt.plot(df_regra["Ativo"], label = "Ativo", alpha = 0.75, linewidth = 2, color = "blue")
plt.plot(df_regra["Media_curta"], label = "Média curta", alpha = 0.75, linewidth = 1, color = "red")
plt.plot(df_regra["Media_longa"], label = "Média longa", alpha = 0.75, linewidth = 1, color = "black")
plt.scatter(df_regra.index, df_regra["Compra"]*0.95, label = "Compra", marker = "^", s = 100, color = "green")
plt.scatter(df_regra.index, df_regra["Venda"]*1.05, label = "Venda", marker = "v", s = 100, color = "red")
plt.title("Regra de trade - Cruzamento de Médias")
plt.legend(loc = "lower right")
plt.xlabel("2018 à 2021")
plt.ylabel("Cotação")
plt.show()


# In[65]:


df_compra = df_regra[ ~ df_regra["Compra"].isna()]
df_compra


# In[66]:


np.array(df_compra["Compra"])


# In[67]:


df_venda = df_regra[ ~ df_regra["Venda"].isna()]
df_venda


# In[68]:


np.array(df_venda["Venda"])


# In[69]:


df_compra.shape


# In[70]:


df_venda.shape


# In[71]:


np.array(df_venda["Venda"])[:-1]


# In[72]:


np.array(df_venda["Venda"])[:-1]-np.array(df_compra["Compra"])


# In[73]:


resultado = round(sum(np.array(df_venda["Venda"])[:-1]-np.array(df_compra["Compra"])), 2)


# In[74]:


print("Resultado por ação: R$ " + str(resultado))

