#!/usr/bin/env python
# coding: utf-8

# ### Curso de Python para Finanças Quantitativas
# 
# #### Aula 2 - Automação com Funções
# #### Autor: Leandro Guerra - Outspoken Market
# #### Download em: https://www.outspokenmarket.com/pythonfinancasquantitativas.html

# In[1]:


# Carregando as bibliotecas necessarias

from pandas_datareader import data as pdr
from datetime import date
import yfinance as yf
yf.pdr_override()
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

import warnings
warnings.filterwarnings("ignore")


# In[2]:


# Configuraçoes iniciais

ticker = "^BVSP"
inicio = "2015-01-01"
fim = "2021-04-12"


# In[3]:


# Coleta dos dados

df = pdr.get_data_yahoo(ticker, start = inicio, end = fim)


# In[4]:


df.head()


# In[5]:


# Primeiro grafico

df["Adj Close"].plot(grid = True, figsize = (20, 15), linewidth = 3, fontsize = 15, color = "darkblue")
plt.xlabel("Data"
           , fontsize = 15);
plt.ylabel("Pontos"
           , fontsize = 15);
plt.title("ibovespa - Python Finanças Quantitativas"
           , fontsize = 25);
plt.legend();


# In[6]:


# Calculando as bandas de bollinger

# Parametros iniciais
periodo = 50
desvios = 2

df["desvio"] = df["Adj Close"].rolling(periodo).std()
df["MM"] = df["Adj Close"].rolling(periodo).mean()
df["Banda_Sup"] = df["MM"] + (df["desvio"]*desvios)
df["Banda_Inf"] = df["MM"] - (df["desvio"]*desvios)


# In[7]:


# Filtrando os valores missing

df = df.dropna(axis = 0) 


# In[8]:


# Inserindo tudo no grafico


df[["Adj Close", "MM", "Banda_Sup", "Banda_Inf"]].plot(grid = True
                                                        , figsize = (20, 15)
                                                        , linewidth = 2
                                                        , fontsize = 15
                                                        , color = ["darkblue", "orange", "green", "red"])
plt.xlabel("Data"
           , fontsize = 15);
plt.ylabel("Pontos"
           , fontsize = 15);
plt.title("ibovespa - Python Finanças Quantitativas"
           , fontsize = 25)
plt.legend();


# In[9]:


# Construcao dos alvos

periodos = 5

# Alvo - Retorno
df.loc[:, "Retorno"] = df["Adj Close"].pct_change(periodos)
df.loc[:, "Alvo"] = df["Retorno"].shift(-periodos)


# In[10]:


df.head()


# In[11]:


df.tail()


# In[12]:


# Filtrando os valores missing

df = df.dropna(axis = 0) 


# In[13]:


# Criando a regra de trade

df.loc[:, "Regra"] = np.where(df.loc[:, "Adj Close"] > df.loc[:, "Banda_Sup"], 1, 0)
df.loc[:, "Regra"] = np.where(df.loc[:, "Adj Close"] < df.loc[:, "Banda_Inf"], -1, df.loc[: , "Regra"])


# In[14]:


# Aplicando a regra no alvo

df.loc[:, "Trade"] = df.loc[:, "Regra"]*df.loc[:, "Alvo"]


# In[15]:


# Calculando o resultado acumulado em juros simples

df.loc[:, "Retorno_Trade_BB"] = df["Trade"].cumsum()


# In[16]:


df["Retorno_Trade_BB"].plot(figsize=(20, 15), linewidth = 3, fontsize = 15, color = "green")
plt.xlabel("Data"
           , fontsize = 15);
plt.ylabel("Pontos"
           , fontsize = 15);
plt.title("ibovespa - Python Finanças Quantitativas"
           , fontsize = 25)
plt.legend();


# ___________________________________________

# ### Automação com Funções

# In[17]:


def minha_funcao(x, y):
    return(x*y)


# In[19]:


minha_funcao(2, 3)


# In[20]:


a = 2
b = 10

minha_funcao(a, b)


# In[21]:


def om_bollinger(ticker, periodo, desvios, inicio, fim, alvo):
    
    df = pdr.get_data_yahoo(ticker, start = inicio, end = fim)
    df["desvio"] = df["Adj Close"].rolling(periodo).std()
    df["MM"] = df["Adj Close"].rolling(periodo).mean()
    df["Banda_Sup"] = df["MM"] + (df["desvio"]*desvios)
    df["Banda_Inf"] = df["MM"] - (df["desvio"]*desvios)
    
    # Filtrando os valores missing
    df = df.dropna(axis = 0) 
    
    # Construcao dos alvos
    df.loc[:, "Retorno"] = df["Adj Close"].pct_change(alvo)
    df.loc[:, "Alvo"] = df["Retorno"].shift(-alvo)
    
    # Filtrando os valores missing
    df = df.dropna(axis = 0) 
    
    # Criando a regra de trade
    df.loc[:, "Regra"] = np.where(df.loc[:, "Adj Close"] > df.loc[:, "Banda_Sup"], 1, 0)
    df.loc[:, "Regra"] = np.where(df.loc[:, "Adj Close"] < df.loc[:, "Banda_Inf"], -1, df.loc[: , "Regra"])

    # Aplicando a regra no alvo
    df.loc[:, "Trade"] = df.loc[:, "Regra"]*df.loc[:, "Alvo"]
    
    # Calculando o resultado acumulado em juros simples
    df.loc[:, "Retorno_Trade_BB"] = df["Trade"].cumsum()
    
    return(df)


# In[24]:


# Parametros da funçao

ticker = "^BVSP"
inicio = "2015-01-01"
fim = "2021-04-12"
periodo = 50
desvios = 2
alvo = 5


# In[25]:


# Chamada da funçao

om_bollinger(ticker, periodo, desvios, inicio, fim, alvo)


# In[26]:


# E se eu quiser apenas o resultado?


# Pega a ùltima linha de cada coluna
om_bollinger(ticker, periodo, desvios, inicio, fim, alvo).iloc[-1]


# In[27]:


# Pega o ùltimo elemento da ùltima linha e coluna

om_bollinger(ticker, periodo, desvios, inicio, fim, alvo).iloc[-1][-1]


# In[28]:


def om_bollinger_resultado(ticker, periodos, desvios, inicio, fim, alvo):
    
    df = pdr.get_data_yahoo(ticker, start = inicio, end = fim)
    df["desvio"] = df["Adj Close"].rolling(periodo).std()
    df["MM"] = df["Adj Close"].rolling(periodo).mean()
    df["Banda_Sup"] = df["MM"] + (df["desvio"]*desvios)
    df["Banda_Inf"] = df["MM"] - (df["desvio"]*desvios)
    
    # Filtrando os valores missing
    df = df.dropna(axis = 0) 
    
    # Construcao dos alvos
    df.loc[:, "Retorno"] = df["Adj Close"].pct_change(alvo)
    df.loc[:, "Alvo"] = df["Retorno"].shift(-alvo)
    
    # Filtrando os valores missing
    df = df.dropna(axis = 0) 
    
    # Criando a regra de trade
    df.loc[:, "Regra"] = np.where(df.loc[:, "Adj Close"] > df.loc[:, "Banda_Sup"], 1, 0)
    df.loc[:, "Regra"] = np.where(df.loc[:, "Adj Close"] < df.loc[:, "Banda_Inf"], -1, df.loc[: , "Regra"])

    # Aplicando a regra no alvo
    df.loc[:, "Trade"] = df.loc[:, "Regra"]*df.loc[:, "Alvo"]
    
    # Calculando o resultado acumulado em juros simples
    df.loc[:, "Retorno_Trade_BB"] = df["Trade"].cumsum()
    
    return(df.iloc[-1][-1])


# In[29]:


om_bollinger_resultado(ticker, periodo, desvios, inicio, fim, alvo)


# In[30]:


# Vamos testar multiplos resultados?


# Uso o print apenas para exibir os 2 resultados em uma mesma cèlula do notebook

print(om_bollinger_resultado(ticker, 20, 1, inicio, fim, 5))
print(om_bollinger_resultado(ticker, 20, 3, inicio, fim, 5))


# In[31]:


# Funçao para plotar o grafico

def plot_resultado(data_frame):
    data_frame["Retorno_Trade_BB"].plot(figsize=(20, 15), linewidth = 3, fontsize = 15, color = "green")
    plt.xlabel("Data"
           , fontsize = 15);
    plt.ylabel("Pontos"
           , fontsize = 15);
    plt.title("Resultado BB Trading - Python Finanças Quantitativas"
           , fontsize = 25)
    plt.legend();


# In[32]:


dados = om_bollinger(ticker, periodo, desvios, inicio, fim, alvo)


# In[33]:


dados


# In[34]:


plot_resultado(dados)

