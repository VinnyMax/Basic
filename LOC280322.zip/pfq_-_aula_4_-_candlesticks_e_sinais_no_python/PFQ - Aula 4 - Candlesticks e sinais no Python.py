#!/usr/bin/env python
# coding: utf-8

# ### Curso de Python para Finanças Quantitativas
# 
# #### Aula 4 - Candlesticks e sinais no Python
# #### Autor: Leandro Guerra - Outspoken Market
# #### Download em: https://www.outspokenmarket.com/pythonfinancasquantitativas.html

# ![image.png](attachment:image.png)

# In[ ]:


#!pip install mplfinance


# In[1]:


# Carregando as bibliotecas necessarias
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import mplfinance as fplt
from pandas_datareader import data as pdr
from datetime import date
import yfinance as yf
yf.pdr_override()

import warnings
warnings.filterwarnings("ignore")


# ___________________________________________

# In[2]:


# Muda o diretorio de trabalho
import os
os.chdir("C:\\Users\\engle\\OM Na Pratica\\Finanças Quantitativas\\Bases de Dados")


# ___________________________________________

# ### Candlestick

# In[3]:


# Parametros da funçao

ticker = "^BVSP"
inicio = "2015-01-01"
fim = "2021-05-31"


# In[4]:


ibov = pdr.get_data_yahoo(ticker, start = inicio, end = fim)


# In[5]:


# Criando o seu gràfico

fplt.plot(
            ibov
            , type = "candle"
            , title = "Ibovespa - 2015/2021 - Outspoken Market"
            , ylabel = "Pontos"
        )


# In[6]:


# Escolhendo apenas 2021

ibov2021 = ibov.loc["2021-01-1":"2021-12-31"]


# In[7]:


# Gràfico de 2021

fplt.plot(
            ibov2021
            , type = "candle"
            , title = "Ibovespa 2021 - Outspoken Market"
            , ylabel = "Pontos"
        )


# In[8]:


# Verificando a lista de estilos disponiveis

fplt.available_styles()


# In[10]:


# Gràfico com novo estilo

fplt.plot(
    ibov2021
    , type = "candle"
    , title = "Ibovespa 2021 - Outspoken Market"
    , ylabel = "Pontos"
    , style = "binance"
    , volume = True
)


# In[11]:


# Adicionando o volume e finais de semana

fplt.plot(
    ibov2021
    , type = "candle"
    , title = "Ibovespa 2021 - Outspoken Market"
    , ylabel = "Pontos"
    , style = "charles"
    , volume = True
    , show_nontrading = True
)


# In[12]:


# Adicionando uma média mòvel

fplt.plot(
    ibov2021
    , type = "candle"
    , title = "Ibovespa 2021 - Outspoken Market"
    , ylabel = "Pontos"
    , style = "charles"
    , volume = True
    , mav = 15
)


# In[13]:


# Mudando o estilo geral

setup = fplt.make_mpf_style(mavcolors = ["yellow", "skyblue"]
                           , base_mpl_style = "fivethirtyeight")

fplt.plot(
    ibov2021
    , type = "candle"
    , title = "Ibovespa 2021 - Outspoken Market"
    , ylabel = "Pontos"
    , style = setup
    , mav = (5, 15)
    , figratio = (12,6)
)


# ___________________________________________

# ### Incluindo indicadores customizados e sinais

# In[14]:


# Càlculo das BB

periodo = 20
desvios = 2
ibov["desvio"] = ibov["Adj Close"].rolling(periodo).std()
ibov["MM"] = ibov["Adj Close"].rolling(periodo).mean()
ibov["Banda_Sup"] = ibov["MM"] + (ibov["desvio"]*desvios)
ibov["Banda_Inf"] = ibov["MM"] - (ibov["desvio"]*desvios)


# In[16]:


ibov2021 = ibov.loc["2021-01-1":"2021-12-31"]


# In[17]:


# Criando o elemento das BB para adicional ao gràfico

bb = fplt.make_addplot(ibov2021[["MM", "Banda_Sup", "Banda_Inf"]])


# In[18]:


# Gràfico com BB

fplt.plot(
    ibov2021
    , type = "candle"
    , title = "Ibovespa 2021 - Outspoken Market"
    , ylabel = "Pontos"
    , style = setup
    , figratio = (12,6)
    , addplot = bb
)


# In[19]:


# Gera o sinal

ibov2021.loc[: , "Sinal_Inf"] = np.where((ibov2021.loc[: , "Close"] < ibov2021.loc[: , "Banda_Inf"] )
                                         , ibov2021.loc[: , "Close"]*0.99
                                         , np.nan)
ibov2021.loc[: , "Sinal_Sup"] = np.where((ibov2021.loc[: , "Close"] > ibov2021.loc[: , "Banda_Sup"] )
                                         , ibov2021.loc[: , "Close"]*1.01
                                         , np.nan)


# In[20]:


ibov2021.head()


# In[21]:


# Cria o vetor de indicadores

indicadores = [fplt.make_addplot(ibov2021["Sinal_Inf"], type = "scatter", markersize = 50, marker = "^", color = "green")
       , fplt.make_addplot(ibov2021["Sinal_Sup"], type = "scatter", markersize = 50, marker = "v", color = "red")
       , fplt.make_addplot(ibov2021[["MM", "Banda_Sup", "Banda_Inf"]], color = "darkblue")
      ]


# In[22]:


# Adicionando os indicadores ao gràfico

fplt.plot(
    ibov2021
    , type = "candle"
    , title = "Ibovespa 2021 - Outspoken Market"
    , ylabel = "Pontos"
    , style = setup
    , figratio = (12,6)
    , addplot = indicadores
)


# In[23]:


# Salva o gràfico em png

fplt.plot(
    ibov2021
    , type = "candle"
    , title = "Ibovespa 2021 - Outspoken Market"
    , ylabel = "Pontos"
    , style = setup
    , figratio = (12,6)
    , addplot = indicadores
    , savefig = "ibov2021.png"
)

