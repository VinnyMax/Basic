#!/usr/bin/env python
# coding: utf-8

# ### Curso de Python para Finanças Quantitativas
# #### Autor: Leandro Guerra - Outspoken Market
# #### Download em: https://www.outspokenmarket.com/pythonfinancasquantitativas.html

# In[1]:


# Carregando as bibliotecas necessarias

from pandas_datareader import data as pdr
from datetime import date
import yfinance as yf
yf.pdr_override()
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


# In[2]:


# Configuraçoes iniciais

ticker = "^BVSP"
inicio = "2015-01-01"
fim = "2021-04-12"


# In[3]:


# Coleta dos dados

df = pdr.get_data_yahoo(ticker, start = inicio, end = fim)


# In[4]:


df.head()


# In[5]:


# Primeiro grafico

df["Adj Close"].plot(grid = True, figsize = (20, 15), linewidth = 3, fontsize = 15, color = "darkblue")
plt.xlabel("Data"
           , fontsize = 15);
plt.ylabel("Pontos"
           , fontsize = 15);
plt.title("ibovespa - Python Finanças Quantitativas"
           , fontsize = 25);
plt.legend();


# In[6]:


# Calculando as bandas de bollinger

# Parametros iniciais
periodo = 50
desvios = 2

df["desvio"] = df["Adj Close"].rolling(periodo).std()
df["MM"] = df["Adj Close"].rolling(periodo).mean()
df["Banda_Sup"] = df["MM"] + (df["desvio"]*desvios)
df["Banda_Inf"] = df["MM"] - (df["desvio"]*desvios)


# In[7]:


# Filtrando os valores missing

df = df.dropna(axis = 0) 


# In[8]:


# Inserindo tudo no grafico


df[["Adj Close", "MM", "Banda_Sup", "Banda_Inf"]].plot(grid = True
                                                        , figsize = (20, 15)
                                                        , linewidth = 2
                                                        , fontsize = 15
                                                        , color = ["darkblue", "orange", "green", "red"])
plt.xlabel("Data"
           , fontsize = 15);
plt.ylabel("Pontos"
           , fontsize = 15);
plt.title("ibovespa - Python Finanças Quantitativas"
           , fontsize = 25)
plt.legend();


# In[9]:


# Construcao dos alvos

periodos = 5

# Alvo - Retorno
df.loc[:, "Retorno"] = df["Adj Close"].pct_change(periodos)
df.loc[:, "Alvo"] = df["Retorno"].shift(-periodos)


# In[10]:


df.head()


# In[11]:


df.tail()


# In[12]:


# Filtrando os valores missing

df = df.dropna(axis = 0) 


# In[13]:


# Criando a regra de trade

df.loc[:, "Regra"] = np.where(df.loc[:, "Adj Close"] > df.loc[:, "Banda_Sup"], 1, 0)
df.loc[:, "Regra"] = np.where(df.loc[:, "Adj Close"] < df.loc[:, "Banda_Inf"], -1, df.loc[: , "Regra"])


# In[14]:


# Aplicando a regra no alvo

df.loc[:, "Trade"] = df.loc[:, "Regra"]*df.loc[:, "Alvo"]


# In[15]:


# Calculando o resultado acumulado em juros simples

df.loc[:, "Retorno_Trade_BB"] = df["Trade"].cumsum()


# In[16]:


df["Retorno_Trade_BB"].plot(figsize=(20, 15), linewidth = 3, fontsize = 15, color = "green")
plt.xlabel("Data"
           , fontsize = 15);
plt.ylabel("Pontos"
           , fontsize = 15);
plt.title("ibovespa - Python Finanças Quantitativas"
           , fontsize = 25)
plt.legend();


# In[17]:


# Testes adicionais:
# O que acontece quando fazendo com 21 dias e alvos em 5 e 10 periodos?
# E quando fazemos para um periodo de 50 dias e alvo em 10 periodos?

