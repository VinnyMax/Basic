#!/usr/bin/env python
# coding: utf-8

# ### Curso de Python para Finanças Quantitativas
# 
# #### Aula 8 - Price Action e análise de dados
# #### Autor: Leandro Guerra - Outspoken Market
# #### Download em: https://www.outspokenmarket.com/pythonfinancasquantitativas.html

# ![image-2.png](attachment:image-2.png)

# In[2]:


import pandas as pd
import numpy as np
from datetime import datetime
import yfinance as yf
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


plt.style.use("fivethirtyeight")
# https://matplotlib.org/stable/gallery/style_sheets/style_sheets_reference.html


# In[4]:


# Carrega a base

df1 = yf.download("^BVSP", "2020-01-01", "2021-12-31")

df1


# In[9]:


# Construção dos alvos

# Alvo 1 - Retorno
df1["Retorno"] = df1["Adj Close"].pct_change(1)*100
df1["Alvo1"] = df1["Retorno"].shift(-1)

# Alvo 5 - Retorno
df1["Retorno5"] = df1["Adj Close"].pct_change(5)*100
df1["Alvo5"] = df1["Retorno5"].shift(-5)

# Alvo 10 - Retorno
df1["Retorno10"] = df1["Adj Close"].pct_change(10)*100
df1["Alvo10"] = df1["Retorno10"].shift(-10)

# Criacao dos alvos categoricos
df1["Alvo1_cat"] = np.where(df1["Alvo1"] > 0 , 1, 0)
df1["Alvo5_cat"] = np.where(df1["Alvo5"] > 0 , 1, 0)
df1["Alvo10_cat"] = np.where(df1["Alvo10"] > 0 , 1, 0)


# In[10]:


df1.head()


# In[12]:


# Cria os pavios (wicks)

# Pavio superior
df1["Wick_upper"] = np.where(df1["Retorno"] > 0
                             , (df1["High"]/df1["Adj Close"]-1)*100
                             , (df1["High"]/df1["Open"]-1)*100)
# Pavio inferior
df1["Wick_lower"] = np.where(df1["Retorno"] > 0
                             , (df1["Open"]/df1["Low"]-1)*100
                             , (df1["Adj Close"]/df1["Low"]-1)*100)

# Direção do dia atual
df1["Dir_D"] = np.where(df1["Retorno"] > 0, "Alta", "Baixa")


# In[13]:


# Visualizando as estatísticas dos Wicks

df1[["Wick_upper", "Wick_lower"]].describe()


# In[14]:


# Visualizando a distribuiçao dos Wicks

df1[["Wick_upper", "Wick_lower"]].plot.hist(bins = 50
                            , alpha = 0.5
                            , title = "Distribuição dos Pavios");


# In[15]:


# Qual é a média do tamanho dos pavios nos dias de alta ou baixa

pd.pivot_table(df1, index = "Dir_D"
               , aggfunc = {"Wick_upper" : np.mean
                            , "Wick_lower": np.mean})


# In[16]:


# Qual é a média dos retornos dos dias sucessivos

pd.pivot_table(df1, index = "Dir_D"
               , aggfunc = {"Alvo1" : np.mean
                            , "Alvo5": np.mean
                            , "Alvo10": np.mean})


# In[19]:


# Não diz muito. Vamos ver agora em relação aos pavios
# Mas antes, vamos dividir os pavios em intervalos

pd.qcut(df1["Wick_upper"], 3)


# In[20]:


pd.qcut(df1["Wick_upper"], 3, labels = ["Baixo", "Médio", "Alto"])


# In[21]:


# Atribuímos os intervalos ao nosso dataframe

df1["Wick_upper_cat"] = pd.qcut(df1["Wick_upper"], 3, labels = ["Baixo", "Médio", "Alto"])
df1["Wick_lower_cat"] = pd.qcut(df1["Wick_lower"], 3, labels = ["Baixo", "Médio", "Alto"])


# In[22]:


# Agora temos algo mais significativo

# Intervalos dos pavios de alta
pd.pivot_table(df1, index = "Wick_upper_cat"
               , aggfunc = {"Alvo1" : [np.mean, np.sum]
                            , "Alvo5": [np.mean, np.sum]
                            , "Alvo10": [np.mean, np.sum]})


# In[23]:


# Intervalos dos pavios de baixa
pd.pivot_table(df1, index = "Wick_lower_cat"
               , aggfunc = {"Alvo1" : [np.mean, np.sum]
                            , "Alvo5": [np.mean, np.sum]
                            , "Alvo10": [np.mean, np.sum]})


# In[24]:


# Dá para ficar melhor? Claro!
# Vamos inserir a direção do dia atual e ter uma visão mais completa

# Analisando o pavio de alta
pd.pivot_table(df1, index = ["Dir_D", "Wick_upper_cat"]
               , aggfunc = {"Alvo1" : [np.mean, np.sum]
                            , "Alvo5": [np.mean, np.sum]
                            , "Alvo10": [np.mean, np.sum]})


# In[25]:


# Analisando o pavio de baixa

pd.pivot_table(df1, index = ["Wick_lower_cat", "Dir_D"]
               , aggfunc = {"Alvo1" : [np.mean, np.sum]
                            , "Alvo5": [np.mean, np.sum]
                            , "Alvo10": [np.mean, np.sum]})


# In[26]:


# Tem como ficar melhor ainda?
# Seguramente. Vamos adicionar uma lógica com uma média movel de 10 dias

df1["MM"] = df1["Adj Close"].rolling(window = 10).mean()
df1["MM_Ref"] = np.where(df1["Adj Close"] > df1["MM"]
                             , "Acima MM"
                             , "Abaixo MM")

pd.pivot_table(df1, index = ["MM_Ref", "Dir_D", "Wick_lower_cat"]
               , aggfunc = {"Alvo1" : [np.mean, np.sum]
                            , "Alvo5": [np.mean, np.sum]
                            , "Alvo10": [np.mean, np.sum]})


# In[27]:


# Ok, agora é impossível ficar melhor?
# Não é. Tem como ficar ainda melhor sim: vamos visualizar!

analise_lower = pd.pivot_table(df1, index = ["MM_Ref", "Wick_lower_cat"]
                         , aggfunc = {"Alvo1" : [np.mean]
                                      , "Alvo5": [np.mean]
                                      , "Alvo10": [np.mean]})

analise_upper = pd.pivot_table(df1, index = ["MM_Ref", "Wick_upper_cat"]
                         , aggfunc = {"Alvo1" : [np.mean]
                                      , "Alvo5": [np.mean]
                                      , "Alvo10": [np.mean]})

sns.heatmap(analise_lower, cmap = "Spectral")
plt.title("Ibov - Mapa de calor dos retornos pós Pavios de Baixa"
          , fontsize = 15)
plt.xlabel("Média dos retornos", fontsize = 15)
plt.ylabel("Intervalos do Pavio e MM", fontsize = 15);


# In[28]:


sns.heatmap(analise_upper, cmap = "Spectral")
plt.title("Ibov - Mapa de calor dos retornos pós Pavios de Alta"
          , fontsize = 15)
plt.xlabel("Média dos retornos", fontsize = 15)
plt.ylabel("Intervalos do Pavio e MM", fontsize = 15);

