#!/usr/bin/env python
# coding: utf-8

# ### Curso de Python para Finanças Quantitativas
# 
# #### Aula 5 - Mapa do IFR e RSL
# #### Autor: Leandro Guerra - Outspoken Market
# #### Download em: https://www.outspokenmarket.com/pythonfinancasquantitativas.html

# ![image.png](attachment:image.png)

# In[ ]:


#!pip install ta
#!pip install yfinance --upgrade --no-cache-dir


# In[1]:


# Carregando as bibliotecas necessarias
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import mplfinance as fplt
from pandas_datareader import data as pdr
from datetime import date
import ta
import yfinance as yf
yf.pdr_override()

import warnings
warnings.filterwarnings("ignore")


# ___________________________________________

# ### Tratamento dos dados

# In[2]:


# Parametros da funçao

tickers = ["^BVSP", "PETR4.SA", "ITUB4.SA", "VALE3.SA", "BBDC4.SA", "BBAS3.SA"]
inicio = "2021-01-01"
fim = "2021-07-31"


# In[3]:


ibov = pdr.get_data_yahoo(tickers, start = inicio, end = fim)


# In[4]:


ibov


# In[7]:


ibov["Adj Close"][["PETR4.SA", "^BVSP", "VALE3.SA"]]


# In[9]:


df_mapa = ibov["Adj Close"][tickers]


# In[8]:


tickers


# In[10]:


df_mapa.head()


# In[11]:


df_mapa.rename(columns = {"^BVSP": "BVSP_Close", "PETR4.SA": "PETR_Close"
                          , "ITUB4.SA": "ITUB_Close", "VALE3.SA": "VALE_Close"
                          , "BBDC4.SA": "BBDC_Close", "BBAS3.SA": "BBAS_Close"}, inplace = True)
df_mapa.head()


# In[12]:


# Calculando o RSL de 10 periodos

p = 10

df_mapa["MM_bvsp"] = df_mapa["BVSP_Close"].rolling(p).mean()
df_mapa["MM_petro"] = df_mapa["PETR_Close"].rolling(p).mean()
df_mapa["MM_itub"] = df_mapa["ITUB_Close"].rolling(p).mean()
df_mapa["MM_vale"] = df_mapa["VALE_Close"].rolling(p).mean()
df_mapa["MM_bbdc"] = df_mapa["BBDC_Close"].rolling(p).mean()
df_mapa["MM_bbas"] = df_mapa["BBAS_Close"].rolling(p).mean()

df_mapa["RSL_BVSP"] = (df_mapa["BVSP_Close"]/df_mapa["MM_bvsp"] - 1)*100
df_mapa["RSL_PETR"] = (df_mapa["PETR_Close"]/df_mapa["MM_petro"] - 1)*100
df_mapa["RSL_ITUB"] = (df_mapa["ITUB_Close"]/df_mapa["MM_itub"] - 1)*100
df_mapa["RSL_VALE"] = (df_mapa["VALE_Close"]/df_mapa["MM_vale"] - 1)*100
df_mapa["RSL_BBDC"] = (df_mapa["BBDC_Close"]/df_mapa["MM_bbdc"] - 1)*100
df_mapa["RSL_BBAS"] = (df_mapa["BBAS_Close"]/df_mapa["MM_bbas"] - 1)*100


# In[13]:


# Calculando o RSI (IFR) de 2 e 14 periodos


petr_rsi2 = ta.momentum.RSIIndicator(close = df_mapa["PETR_Close"], window = 2)
petr_rsi14 = ta.momentum.RSIIndicator(close = df_mapa["PETR_Close"], window = 14)

bvsp_rsi2 = ta.momentum.RSIIndicator(close = df_mapa["BVSP_Close"], window = 2)
bvsp_rsi14 = ta.momentum.RSIIndicator(close = df_mapa["BVSP_Close"], window = 14)

itub_rsi2 = ta.momentum.RSIIndicator(close = df_mapa["ITUB_Close"], window = 2)
itub_rsi14 = ta.momentum.RSIIndicator(close = df_mapa["ITUB_Close"], window = 14)

vale_rsi2 = ta.momentum.RSIIndicator(close = df_mapa["VALE_Close"], window = 2)
vale_rsi14 = ta.momentum.RSIIndicator(close = df_mapa["VALE_Close"], window = 14)

bbdc_rsi2 = ta.momentum.RSIIndicator(close = df_mapa["BBDC_Close"], window = 2)
bbdc_rsi14 = ta.momentum.RSIIndicator(close = df_mapa["BBDC_Close"], window = 14)

bbas_rsi2 = ta.momentum.RSIIndicator(close = df_mapa["BBAS_Close"], window = 2)
bbas_rsi14 = ta.momentum.RSIIndicator(close = df_mapa["BBAS_Close"], window = 14)


df_mapa["RSI2_PETR"] = petr_rsi2.rsi()
df_mapa["RSI14_PETR"] = petr_rsi14.rsi()

df_mapa["RSI2_BVSP"] = bvsp_rsi2.rsi()
df_mapa["RSI14_BVSP"] = bvsp_rsi14.rsi()

df_mapa["RSI2_ITUB"] = itub_rsi2.rsi()
df_mapa["RSI14_ITUB"] = itub_rsi14.rsi()

df_mapa["RSI2_VALE"] = vale_rsi2.rsi()
df_mapa["RSI14_VALE"] = vale_rsi14.rsi()

df_mapa["RSI2_BBDC"] = bbdc_rsi2.rsi()
df_mapa["RSI14_BBDC"] = bbdc_rsi14.rsi()

df_mapa["RSI2_BBAS"] = bbas_rsi2.rsi()
df_mapa["RSI14_BBAS"] = bbas_rsi14.rsi()


# In[14]:


df_mapa.head()


# In[15]:


# Filtrando os valores missing

df_mapa = df_mapa.dropna(axis = 0) 


# In[16]:


df_mapa.head()


# In[20]:


df_mapa["RSL_PETR"].tail(1)[0]


# ___________________________________________

# ### Criando o mapa

# In[32]:


# Preparando o dataframe

# Agrupando os dados
indicadores = [
                  ["PETR4", df_mapa["RSL_PETR"].tail(1)[0], df_mapa["RSI14_PETR"].tail(1)[0]]
                , ["BVSP", df_mapa["RSL_BVSP"].tail(1)[0], df_mapa["RSI14_BVSP"].tail(1)[0]]
                , ["ITUB4", df_mapa["RSL_ITUB"].tail(1)[0], df_mapa["RSI14_ITUB"].tail(1)[0]]
                , ["VALE3", df_mapa["RSL_VALE"].tail(1)[0], df_mapa["RSI14_VALE"].tail(1)[0]]
                , ["BBDC4", df_mapa["RSL_BBDC"].tail(1)[0], df_mapa["RSI14_BBDC"].tail(1)[0]]
                , ["BBAS3", df_mapa["RSL_BBAS"].tail(1)[0], df_mapa["RSI14_BBAS"].tail(1)[0]]
              ]
 
# Criar o DataFrame do pandas
mapa = pd.DataFrame(indicadores, columns = ["Ativo", "RSL", "RSI14"])

mapa.head(6)


# In[22]:


# Algumas considerações interessantes

plt.plot(df_mapa["RSL_PETR"], df_mapa["RSI2_PETR"], ".", color = "blue")
plt.title("PETR4 - RSL(10) e RSI(2)");


# In[23]:


plt.plot(df_mapa["RSL_PETR"], df_mapa["RSI14_PETR"], ".", color = "blue")
plt.title("PETR4 - RSL(10) e RSI(14)");


# In[24]:


plt.plot(df_mapa["RSL_BVSP"], df_mapa["RSI2_BVSP"], ".", color = "green")
plt.title("ibovespa - RSL(10) e RSI(2)");


# In[29]:


plt.plot(df_mapa["RSL_BBAS"], df_mapa["RSI14_BBAS"], "x", color = "green")
plt.title("BBAS3 - RSL(10) e RSI(14)");


# In[35]:


mapa


# In[37]:


plt.figure(figsize = (12, 8))

plt.scatter(mapa["RSL"], mapa["RSI14"], s = 80)
for i in range(mapa.shape[0]):
    plt.text(x = mapa.RSL[i] + 0.3, y = mapa.RSI14[i] + 0.3 , s = mapa.Ativo[i], 
             fontdict = dict(color = "white", size = 14),
             bbox = dict(facecolor = "black", alpha = 0.7))

plt.xlim(mapa.RSL.min() - 1, mapa.RSL.max() + 1)               
plt.ylim(mapa.RSI14.min() - 2, mapa.RSI14.max() + 4)          

setup = dict(size = 13, color = "black")
plt.text(-3, 52.5, "www.outspokenmarket.com", **setup)

plt.title("Mapa do RSI e RSL - 30.07.2021") 
plt.xlabel("RSL(10) em %")                        
plt.ylabel("RSI(14)")                     
plt.show()

