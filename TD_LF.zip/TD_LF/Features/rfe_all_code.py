# https://github.com/k3ybladewielder?tab=repositories


# imports
import pandas as pd
from sklearn.datasets import make_regression
from sklearn.feature_selection import RFE
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold, GridSearchCV

# simulando um dataset
X, y = make_regression(n_samples=1000, n_features=50, n_informative=5, random_state=1)

# Simulando um df (para exibir o nome das colunas abaixo)
X = pd.DataFrame(X)

# crie o cross-validation;
folds = KFold(n_splits = 5, shuffle = True, random_state = 100)

# selecionando todas as features
hyper_params = [{'n_features_to_select': list(range(1, len(X)+1))}]

# aplique o grid search ao modelo (ex. OLS linear regression do sklearn)
lm = LinearRegression()
lm.fit(X, y)
rfe = RFE(lm)

# chame o GridSearchCV(). O parâmetro "return_train_score = True" Garante que a pontuação do treino
# seja retornada junto com a do teste;
model_cv = GridSearchCV(estimator = rfe, param_grid = hyper_params, scoring= 'neg_mean_squared_error',
                        cv = folds, verbose = 1, return_train_score=True)

# fitando o modelo
model_cv.fit(X, y)

# Listando as features
for i in range(X.shape[1]):
    sel = model_cv.best_estimator_.support_[i]
    col_name = X.columns[i]
    rank = model_cv.best_estimator_.ranking_[i]
    
    print(f'Column: {i}, Column Name: {col_name}, Selected {sel}, Rank: {rank}')
